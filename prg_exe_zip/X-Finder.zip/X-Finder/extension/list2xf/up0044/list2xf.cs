﻿using System;
using System.IO;
using System.Text;
using System.Collections.Generic;

namespace list2xf
{
    class list2xf
    {
        private const string usageText = "Usage: list2xf [-i filelist.txt] [-o output.ini]";

        public static int DoConvert(string ipath, string opath)
        {
            Encoding enc = Encoding.GetEncoding("shift_jis");
            List<string> entries = new List<string>();
            try
            {
                using (TextWriter writer = (opath == null) ? Console.Out : new StreamWriter(opath, false, enc))
                {
                    using (TextReader reader = (ipath == null) ? Console.In : new StreamReader(ipath, enc))
                    {
                        string line;
                        while ((line = reader.ReadLine()) != null)
                            entries.Add(line);
                    }

                    writer.WriteLine("[X-Finder]\r\nCount={0}", entries.Count);
                    for (int i = 0; i < entries.Count; ++i)
                        writer.WriteLine("Name{0}={1}\r\nPath{0}=\"{2}\"\r\nType{0}=1\r\nIcon{0}=\r\nExt{0}=",
                                         i, Path.GetFileName(entries[i]), entries[i]);
                    return entries.Count;
                }
            }
            catch (Exception e)
            {
                Console.Error.WriteLine(e.Message+"\r\n"+usageText);
                return 0;
            }
        }


        public static Dictionary<string, string> GetArgs(string[] args)
        {
            Dictionary<string, string> opt = new Dictionary<string, string>();
            opt.Add("in", null);
            opt.Add("out", null);

            if ((args.Length == 0 && Console.In.Peek() < 0) || args.Length % 2 == 1)
                return null;
            else
            {
                for (int i = 0; i < args.Length; ++i )
                {
                    switch (args[i])
                    {
                        case "-i":
                            opt["in"] = args[++i];
                            break;
                        case "-o":
                            opt["out"] = args[++i];
                            break;
                        default:
                            return null;
                    }
                }
                return opt;
            }
        }


        public static int Main(string[] args)
        {
            Dictionary<string,string> opt = GetArgs(args);
            if (opt == null)
            {
                Console.WriteLine(usageText);
                return 1;
            }

            int lines = DoConvert(opt["in"], opt["out"]);
            
            Console.Error.WriteLine("{0} -> {1}: {2} lines processed.", 
                                    opt["in"]==null?"<stdin>" :opt["in"],
                                    opt["out"]==null?"<stdout>":opt["out"],
                                    lines);
            return 0;
        }
    }
}
